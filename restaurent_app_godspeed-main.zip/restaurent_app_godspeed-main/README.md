## Getting started


The fastest way to get started with Godspeed is by following the [Godspeed documentation](https://docs.mindgrep.com/).